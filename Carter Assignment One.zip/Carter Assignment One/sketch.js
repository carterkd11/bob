function setup() {
  createCanvas(500, 500);
  background(100);
}

function draw() {
let b = color(0);
fill(b);
noStroke();
rect(400, 300, 50, 200);

fill(b);
noStroke();
rect(350, 250, 50, 250);

fill(b);
noStroke();
rect(300, 350, 50, 150);

fill(b);
noStroke();
rect(250, 200, 50, 300);

fill(b);
noStroke();
rect(200, 250, 50, 250);

fill(b);
noStroke();
rect(150, 200, 50, 300);

fill(b);
noStroke();
rect(100, 350, 50, 150);

fill(b);
noStroke();
rect(50, 250, 50, 250);

fill(b);
noStroke();
rect(0, 300, 50, 200);

let a = color(225);
fill(a);
noStroke();
ellipse(400, 100, 100, 100);

fill(a);
strokeWeight(12.0);
strokeCap(ROUND);
line(200, 50, 100, 50);
strokeCap(ROUND);
line(200, 70, 100, 70);
strokeCap(ROUND);
line(200, 90, 100, 90);
}
