
// initialize variables
let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 0;
let eSize = 3; // Original Size
let eLoc = 10; // Original Location

function setup() {

	createCanvas(700, 700);
	background(124);

	strokeWeight(4);
	stroke(0, 102);

	let fr = 30;
	frameRate(fr);
}


function draw() {

	colorMode(RGB, 255, 255, 255, 1);

	let fr = sqrt(75);
	frameRate(fr);

	print(fr);

	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;

	var weight = dist(mx, my, px, py);

	strokeWeight (weight);

	stroke(35, 140, 205, 0.75);

	ellipse(mx, my, px, py);

	let a = color(255, 204, 0);
	fill(a);
	noStroke();
	ellipse(eLoc, eLoc, eSize, eSize);
	let b = color(109, 74, 200);
	fill(b);
	noStroke();
  	ellipse(eLoc * 2, eLoc * 2, pow(eSize, 2), pow(eSize, 2));
	fill(a);
	noStroke();
  	ellipse(eLoc * 4, eLoc * 4, pow(eSize, 3), pow(eSize, 3));
	fill(b);
	noStroke();
  	ellipse(eLoc * 8, eLoc * 8, pow(eSize, 4), pow(eSize, 4));

}