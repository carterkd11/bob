function setup() {
  createCanvas(300, 300);
  background(175);
}

function draw() {
let a = color(123, 204, 49);
fill(a);
noStroke();
triangle(100, 90, 45, 34, 65, 100);

let b = color(100, 0, 150);
fill(b);
noStroke();
quad(128, 25, 118, 20, 100, 34, 135, 15);

let c = color(205, 0, 65, 2);
fill(c);
noStroke();
arc(150, 150, 200, 200, 0, PI + QUARTER_PI, PIE);


let d = color(185, 155, 95);
fill(d);
noStroke();
triangle(45, 225, 58, 200, 45, 275);
}